Zaphod Beeblebrox
Epicurus
Hypatia
